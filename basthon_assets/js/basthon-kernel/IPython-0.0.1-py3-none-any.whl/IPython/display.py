import pyodide

__all__ = ["display", "display_image"]


display = pyodide.Basthon.basthon_internal.display

display_image = pyodide.Basthon.basthon_internal.display_image
